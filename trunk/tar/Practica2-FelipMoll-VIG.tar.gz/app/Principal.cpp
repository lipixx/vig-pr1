#include "Principal.h"

Principal::Principal(QWidget *parent):QWidget(parent)
{
	ui.setupUi(this);
}
