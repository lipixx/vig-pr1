#include "ui_Principal.h"

class Principal:public QWidget
{
	Q_OBJECT
	public:
		Principal(QWidget *parent=0);
	
	private:
		Ui::Principal ui;
};
