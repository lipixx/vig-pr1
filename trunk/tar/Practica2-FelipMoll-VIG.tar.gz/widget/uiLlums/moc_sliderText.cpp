/****************************************************************************
** Meta object code from reading C++ file 'sliderText.h'
**
** Created: Tue Apr 27 18:10:03 2010
**      by: The Qt Meta Object Compiler version 59 (Qt 4.4.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "sliderText.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sliderText.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.4.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_sliderText[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   10, // methods
       1,   25, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      34,   30,   11,   11, 0x09,
      54,   52,   11,   11, 0x09,

 // properties: name, type, flags
      79,   75, 0x02095003,

       0        // eod
};

static const char qt_meta_stringdata_sliderText[] = {
    "sliderText\0\0valueChanged(int)\0val\0"
    "sliderChange(int)\0s\0textChanged(QString)\0"
    "int\0tam\0"
};

const QMetaObject sliderText::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_sliderText,
      qt_meta_data_sliderText, 0 }
};

const QMetaObject *sliderText::metaObject() const
{
    return &staticMetaObject;
}

void *sliderText::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_sliderText))
        return static_cast<void*>(const_cast< sliderText*>(this));
    return QWidget::qt_metacast(_clname);
}

int sliderText::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: sliderChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        }
        _id -= 3;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = size(); break;
        }
        _id -= 1;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setSize(*reinterpret_cast< int*>(_v)); break;
        }
        _id -= 1;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void sliderText::valueChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
