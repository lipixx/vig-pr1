#include "vertex.h"

Vertex::Vertex(const Point& coordenades)
: coord(coordenades)
{}


